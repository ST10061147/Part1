﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//author: ST10061147

namespace Val_s_prog1
{
	internal class recipe
	{

		private static string[] unitOfMeasure;//my arrays for recipes values
		private static double[] quautiy;
		private static string[] nameOfInred;
		static int numOfIngredients = 0;
		static Steps steps = new Steps();//calling a class
		static string factor;
		public recipe() 
		{
			IngredientsScreen();
			while (true)//this loop returns to the menu options
			{
				Menu();
			}
		}

		public static string[] NameOfInred { get => nameOfInred; set => nameOfInred = value; }//Where i setting and getting array values
		public static string[] UnitOfMeasure { get => unitOfMeasure; set => unitOfMeasure = value; }
		public static double[] Quautiy { get => quautiy; set => quautiy = value; }

		public static void IngredientsScreen()
		{
			Console.WriteLine(" ------- Weclome! enter your ingredients to create an recipe -------");
			Console.WriteLine("Please enter how many ingredients you want to put in the recipe: ");
			 numOfIngredients = Convert.ToInt32(Console.ReadLine());

			NameOfInred = new string[numOfIngredients];
			quautiy = new double[numOfIngredients];
			UnitOfMeasure = new string[numOfIngredients];
			int add = 1;

			for (int i = 0; i < numOfIngredients; i++)
			{
				Console.WriteLine($"------- new ingredient: {add++} -------");
				Console.WriteLine("Enter the name of your ingredient : ");
				NameOfInred[i] = Console.ReadLine();
				Console.WriteLine("Enter the quautity of your ingredient: ");
				quautiy[i]=Convert.ToDouble(Console.ReadLine());	
				Console.WriteLine("Enter the measurement of your ingredient: ");
				UnitOfMeasure[i]=Console.ReadLine();
			}
			steps.playSteps();
		}

		public static void Menu()//this is where the magica happens where the menu option display and receive input
		{
			Console.WriteLine("Choosing from the following: \n" +
				"1.Enter an new recipe\n" +
				"2. Display the recipe\n" +
				"3. Change the quautity \n" +
				"4. Return the quautity to normal\n" +
				"5. Clear all");
			string menu = Console.ReadLine();
			if (menu == "1")
			{
				IngredientsScreen();
			}
			else if (menu =="2")
			{
				Display();
			}
			else if (menu =="3")
			{
				Factoring();
			}
			else if (menu == "4")
			{
				FactorRestarting();
			}
			else if (menu =="5")
			{
				Cleaning();
			}
		}

		public static void Display()//this print's out the details of the recipe entered
		{
			Console.WriteLine("Displaying the recipe: \n");
			int add = 1;
			for (int i = 0; i < numOfIngredients; i++)
			{
				Console.WriteLine($"Ingredient: {add++}");
				Console.WriteLine("Ingredient Name: " + NameOfInred[i]+"\n" +
					"Ingredient Quautity: " + Quautiy[i]+"\n" +
					"Ingredient unit of measurement: " + UnitOfMeasure[i]);
			}
			steps.prrint();
			Console.WriteLine("Press enter to go back");
			Console.ReadLine();
		}

		public static void Factoring()//this changes the quautity value by factor of 0.5 or 2 or 3
		{
			//author: ST10061147

			Console.WriteLine("Factoring homes \n" +
				"1. Factor by 0.5\n" +
				"2. Factor by 2\n" +
				"3. Factor by 3" );
			 factor = Console.ReadLine();

			if (factor == "1")
			{
				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] *= 0.5;
				}
				Console.WriteLine("Modified recipe: \n");
				Display();
			}
			else if (factor == "2")
			{
				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] *= 2;
				}
				Console.WriteLine("Modified recipe: \n");
				Display();
			}
			else if (factor == "3")
			{
				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] *= 3;
				}
				Console.WriteLine("Modified recipe: \n");
				Display();
			}
		}
		public static void FactorRestarting()//returns the original values of the quautity
		{
			Console.WriteLine("You are restart your quautity \n" +
				"Why did you even do it?");

			Console.WriteLine("The before recipe with the Factored values");
			Display();
			Console.WriteLine("******************************");
			if (factor == "1")
			{

				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] *= 2;
				}
				Console.WriteLine("The fixed recipe with the unfactored values by: "+0.5);
				Display();
			}
			else if(factor == "2")
			{

				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] /= 2;
				}
				Console.WriteLine("The fixed recipe with the unfactored values by: " + 0.5);
				Display();
			}
			else if (factor == "3")
			{

				for (int i = 0; i < numOfIngredients; i++)
				{
					Quautiy[i] /= 3;
				}
				Console.WriteLine("The fixed recipe with the unfactored values by: " + 0.5);
				Display();
			}
			Console.WriteLine("****************************");
		}

		public static void Cleaning() //does the job of cleaning
		{
			Array.Clear(UnitOfMeasure, 0, numOfIngredients);
			Array.Clear(Quautiy, 0, numOfIngredients);
			Array.Clear(NameOfInred, 0, numOfIngredients);
			Array.Clear(steps.StepDisplay, 0, steps.Step1);
			Console.WriteLine("========= Cleared all ============");
			 Display();
		}
	}
}
