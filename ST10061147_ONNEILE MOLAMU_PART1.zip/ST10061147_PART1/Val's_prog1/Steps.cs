﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Val_s_prog1
{
	internal class Steps
	{
		private string[] stepDisplay;
		private int steps;
		public string[] StepDisplay { get => stepDisplay; set => stepDisplay = value; }
		public int Step1{ get => steps; set => steps = value; }
//this class is for storing and setting of steps used to prepare a recipes
		public void playSteps()
		{
			Console.WriteLine("Enter how many steps required: ");
			Step1 = Convert.ToInt32(Console.ReadLine());
			StepDisplay = new string[Step1];
			int add = 1;
			for (int i = 0; i < Step1; i++)
			{
				Console.WriteLine("Enter the step " + add++ + " to prepare: ");
				StepDisplay[i] = Console.ReadLine();
			}
		}

		public void prrint()
		{
			int add = 1;
			for (int i = 0; i < Step1; i++)
			{
				Console.WriteLine("step"+ add++ +": " + StepDisplay[i]);
			}
		}
	}
	//author: ST10061147
}
